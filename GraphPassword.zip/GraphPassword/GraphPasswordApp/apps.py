from django.apps import AppConfig


class GraphpasswordappConfig(AppConfig):
    name = 'GraphPasswordApp'
